package me.tofpu.speedbridge.data.file.path;

public class Value<T> {

}
