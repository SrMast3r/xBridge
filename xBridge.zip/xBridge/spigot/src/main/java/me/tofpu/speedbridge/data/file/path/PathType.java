package me.tofpu.speedbridge.data.file.path;

public enum PathType {
    SETTINGS, MESSAGES;
}
