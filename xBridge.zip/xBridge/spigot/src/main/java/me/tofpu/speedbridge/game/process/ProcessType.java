package me.tofpu.speedbridge.game.process;

public enum ProcessType {
    PROCESS, REVERSE
}
