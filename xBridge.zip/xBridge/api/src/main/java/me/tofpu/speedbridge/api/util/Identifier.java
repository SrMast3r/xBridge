package me.tofpu.speedbridge.api.util;

/**
 * An utility that allows classes to be identified.
 */
public interface Identifier {
    /**
     * @return the identifier
     */
    String identifier();
}
